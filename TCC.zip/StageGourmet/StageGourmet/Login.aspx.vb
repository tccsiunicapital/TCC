﻿Public Class Login
    Inherits System.Web.UI.Page

#Region "Variaveis"
    Private Usuario As Usuario
    Private Log As New Log

    Public appId As String = ConfigurationManager.AppSettings.Get("appId")
    Public appSecret As String = ConfigurationManager.AppSettings.Get("appSecret")
#End Region

#Region "Protectec"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

#End Region

#Region "Private"

    Private Sub LoginUsr(ByVal usuario As String, senha As String)
        Try
            Dim ds As DataSet
            Dim u As New Usuario
            Dim s As String = u.Crypto(senha)
            senha = ""

            ds = u.LoginUsr(usuario, s)

            If ds IsNot Nothing Then
                If ds.Tables(0).Rows.Count > 0 Then
                    Session("login") = ds.Tables(0).Rows(0)("id_usuario")
                    Session("nome") = ds.Tables(0).Rows(0)("nome")
                    Me.ltlMsg.Visible = False
                Else
                    Session("login") = ""
                    Session("nome") = ""
                End If

                If Session("current_page") <> "" Then
                    Response.Redirect(Session("current_page"), False)
                Else
                    Response.Redirect("/index.aspx", False)
                End If
            End If

        Catch ex As Exception
            Log.WriteLog("Login.LoginUsr", ex.Message.ToString)
            Me.ltlMsg.Text = "Usuário ou senha incorretos..."
            Me.ltlMsg.Visible = True
        End Try
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
        Try
            If Not Me.IsEmailValid(Me.txtUsuario.Text) Then
                ltlMsg.Text = "Email Inválido"
                ltlMsg.Visible = True
            Else
                Me.LoginUsr(Me.txtUsuario.Text, Me.txtSenha.Text)
            End If
        Catch ex As Exception
            Log.WriteLog("Login.btnLogin_Click", ex.Message.ToString)
        End Try
    End Sub

    Private Sub lnkCadastrar_Click(sender As Object, e As System.EventArgs) Handles lnkCadastrar.Click
        Try
            Response.Redirect("/Cadastro.aspx", False)
        Catch ex As Exception
            Log.WriteLog("Login.btnLogin_Click", ex.Message.ToString)
        End Try
    End Sub

    Private Function IsEmailValid(ByVal email As String) As Boolean
        Dim padrao As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailMatch As Match = Regex.Match(email, padrao)
        If emailMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

#End Region

End Class