﻿Public Class Restaurantes_Det
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Log As New Log
    Private Restaurantes As New DALRestaurantes

#End Region

#Region "Protected"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri
            If Not Page.IsPostBack Then
                Dim parm As Long = CLng(Request.Params("parm"))
                If parm > 0 Then Me.Carrega(parm)
            End If
        Catch ex As Exception
            Log.WriteLog("Restaurantes.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

#End Region

#Region "Private"

    Private Sub Carrega(id As Long)
        Try
            Dim ds As DataSet = Restaurantes.Carrega(id)
            Restaurantes.RegistraVisualizacao(id)

            Me.ltlNome.Text = ds.Tables(0).Rows(0)("nome")
            Me.ltlDescricao.Text = ds.Tables(0).Rows(0)("descricao")
            Me.ltlLogradouro.Text = ds.Tables(0).Rows(0)("logradouro")
            Me.ltlNumero.Text = ds.Tables(0).Rows(0)("numero")
            Me.ltlComplemento.Text = ds.Tables(0).Rows(0)("complemento")
            Me.ltlBairro.Text = ds.Tables(0).Rows(0)("bairro")
            Me.ltlMunicipio.Text = ds.Tables(0).Rows(0)("municipio")
            Me.ltlUF.Text = ds.Tables(0).Rows(0)("uf")
            Me.ltlCEP.Text = ds.Tables(0).Rows(0)("cep")
            Me.ltlPrecoDe.Text = FormatCurrency(ds.Tables(0).Rows(0)("preco_minimo"))
            Me.ltlPrecoAte.Text = FormatCurrency(ds.Tables(0).Rows(0)("preco_maximo"))
            Me.ltlTipoCozinha.Text = ds.Tables(0).Rows(0)("tipo_cozinha")

            Me.hLink.Text = ds.Tables(0).Rows(0)("site")
            Dim l As String = "Javascript:window.open('" & ds.Tables(0).Rows(0)("site") & "','poupup')"
            Me.lblSite.Attributes.Add("onClick", l)
            Me.hLink.NavigateUrl = "Javascript:window.open('" & ds.Tables(0).Rows(0)("site") & "')"

            Me.ltlEmail.Text = ds.Tables(0).Rows(0)("email")
            Me.ltlDDD.Text = ds.Tables(0).Rows(0)("ddd")
            Me.ltlFone.Text = ds.Tables(0).Rows(0)("telefone")

            If IO.File.Exists((Me.Server.MapPath("Imagens\Restaurantes\") & ds.Tables(0).Rows(0)("id_restaurante") & ".jpg")) Then
                Me.Image1.Visible = True
                Me.Image1.ImageUrl = "Imagens/Restaurantes/" & ds.Tables(0).Rows(0)("id_restaurante") & ".jpg"
            End If

            Session("url_mail") = HttpContext.Current.Request.Url.AbsoluteUri

        Catch ex As Exception
            Log.WriteLog("Restaurantes.aspx.vb.Carrega", ex.Message.ToString)
        End Try
    End Sub

#End Region

End Class