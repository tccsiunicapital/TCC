﻿Public Class Receitas_Det
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Log As New Log
    Private Receitas As New DALReceitas
    Private Email As New Email

#End Region

#Region "Protected"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri
            If Not Page.IsPostBack Then
                Dim parm As Long = CLng(Request.Params("parm"))
                If parm > 0 Then
                    If Not Me.Carrega(parm) Then
                        Response.Redirect("404.aspx")
                    End If
                    Receitas.RegistraVisualizacao(parm)
                End If
            End If
        Catch ex As Exception
            Log.WriteLog("Receitas_Det.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

#End Region

#Region "Public"

    Public Function Carrega(id As Long) As Boolean
        Try
            Carrega = False

            Dim ds As DataSet = Receitas.Carrega(id)

            If ds.Tables(0).Rows.Count > 0 Then

                Me.ltlNome.Text = ds.Tables(0).Rows(0)("nome")
                Me.ltlDescricao.Text = ds.Tables(0).Rows(0)("descricao")
                Me.ltlIngredientes.Text = ds.Tables(0).Rows(0)("ingredientes").ToString.Replace(Environment.NewLine, "</br>")
                Me.ltlModoPreparo.Text = ds.Tables(0).Rows(0)("modo_preparo").ToString.Replace(Environment.NewLine, "</br>")
                Me.ltlTipo_cozinha.Text = ds.Tables(0).Rows(0)("tipo_cozinha")
                Me.ltlTipo_prato.Text = ds.Tables(0).Rows(0)("nome_prato")

                If IO.File.Exists((Me.Server.MapPath("Imagens\Receitas\") & ds.Tables(0).Rows(0)("id_receita") & ".jpg")) Then
                    Me.Image1.Visible = True
                    Me.Image1.ImageUrl = "Imagens/Receitas/" & ds.Tables(0).Rows(0)("id_receita") & ".jpg"
                End If

                Session("url_mail") = HttpContext.Current.Request.Url.AbsoluteUri

                Carrega = True

            End If
        Catch ex As Exception
            Carrega = False
            Log.WriteLog("Receitas_Det.aspx.vb.Carrega", ex.Message.ToString)
        End Try
    End Function

#End Region

#Region "Private"

    Private Function EnviaEmail() As Boolean
        Try
            Session("url_mail") = HttpContext.Current.Request.Url.AbsoluteUri
            Response.Redirect("~/EnvioEmail.aspx", False)
            Return True
        Catch ex As Exception
            Log.WriteLog("Receitas_Det.aspx.vb.EnviaEmail", ex.Message.ToString)
            Return False
        End Try
    End Function

#End Region

End Class