﻿Public Class MasterPage
    Inherits System.Web.UI.MasterPage

    Private usuario As Usuario
    Private Log As New Log

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Logado()
    End Sub

    Private Function Logado() As Boolean
        Try
            If Session("login") = "" Then
                Me.lkbSair.Visible = False
                Me.lkbLogin.Visible = True
                Me.ltlUsuario.Text = ""
                Me.lkbEnviarReceitas.Visible = False
                Me.lkbEnviarRestaurantes.Visible = False
                Return False
            Else

                Dim nome As String

                If InStr(Session("nome").ToString.Trim, " ") > 0 Then
                    nome = "Olá, " & Mid(Session("nome").ToString, 1, InStr(Session("nome").ToString, " ") - 1) & "!"
                Else
                    nome = "Olá, " & Session("nome").ToString.Trim
                End If

                Me.lkbSair.Visible = True
                Me.lkbLogin.Visible = False
                Me.ltlUsuario.Text = nome
                Me.ltlUsuario.Visible = True
                Me.lkbEnviarReceitas.Visible = True
                Me.lkbEnviarRestaurantes.Visible = True
                Return True
            End If
        Catch ex As Exception
            Log.WriteLog("MasterPage.aspx.vb.Logado", ex.Message.ToString)
            Return False
        End Try
    End Function

    Private Sub lkbSair_Click(sender As Object, e As System.EventArgs) Handles lkbSair.Click
        Try
            If Me.Logout() Then
                Response.Redirect(Session("current_page"), False)
            End If
        Catch ex As Exception
            Log.WriteLog("MasterPage.aspx.vb.lkbSair_Click", ex.Message.ToString)
        End Try
    End Sub

    Private Function Logout() As Boolean
        Try
            Session("login") = ""
            Session("nome") = ""
            Return True
        Catch ex As Exception
            Log.WriteLog("MasterPage.aspx.vb.Logout", ex.Message.ToString)
            Return False
        End Try
    End Function

    Private Sub lkbLogin_Click(sender As Object, e As System.EventArgs) Handles lkbLogin.Click
        Response.Redirect("/Login.aspx", False)
    End Sub

    Private Sub lkbBuscar_Click(sender As Object, e As System.EventArgs) Handles lkbBuscar.Click
        Response.Redirect("/Busca.aspx", False)
    End Sub

    Private Sub lkbEnviarReceitas_Click(sender As Object, e As System.EventArgs) Handles lkbEnviarReceitas.Click
        Response.Redirect("/Receitas_Cad.aspx", False)
    End Sub

    Private Sub lkbEnviarRestaurantes_Click(sender As Object, e As System.EventArgs) Handles lkbEnviarRestaurantes.Click
        Response.Redirect("/Restaurantes_Cad.aspx", False)
    End Sub

    Private Sub lkbIndex_Click(sender As Object, e As System.EventArgs) Handles lkbIndex.Click
        Response.Redirect("/index.aspx", False)
    End Sub

    Private Sub lkbReceitas_Click(sender As Object, e As System.EventArgs) Handles lkbReceitas.Click
        Response.Redirect("/Receitas.aspx", False)
    End Sub

    Private Sub lkbRestaurantes_Click(sender As Object, e As System.EventArgs) Handles lkbRestaurantes.Click
        Response.Redirect("/Restaurantes.aspx", False)
    End Sub

End Class