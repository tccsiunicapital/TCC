﻿Public Class Cadastro
    Inherits System.Web.UI.Page

    Private Usuario As Usuario
    Private Log As New Log

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Function Cadastra(ByVal usuario As String, ByVal nome As String, ByVal senha As String) As Boolean
        Try
            Dim u As New Usuario
            Dim s As String = u.Crypto(senha)
            senha = ""

            If u.Cadastra(usuario, nome, s) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Log.WriteLog("Cadastro.Cadastra", ex.Message.ToString)
            Return False
        End Try
    End Function

    Private Sub btnCadastrar_Click(sender As Object, e As System.EventArgs) Handles btnCadastrar.Click
        Try
            If Not IsEmailValid(txtEmail.Text) Then
                ltlMsg.Text = "Email Inválido"
                ltlMsg.Visible = True
                Exit Sub
            End If

            If txtSenha.Text.Trim.Length < 6 Or txtSenha.Text.Trim.Length > 8 Then
                ltlMsg.Text = "Sua senha deve ter entre 6 e 8 caracteres."
                ltlMsg.Visible = True
                Exit Sub
            End If

            If Me.Cadastra(txtEmail.Text, txtNome.Text, txtSenha.Text) Then
                ltlMsg.Text = "Usuário cadastrado com sucesso."
                ltlMsg.Visible = True

                Session("login") = txtEmail.Text
                Session("nome") = txtNome.Text

                If Session("current_page") <> "" Then
                    Response.Redirect(Session("current_page"), False)
                Else
                    Response.Redirect("/index.aspx", False)
                End If

            Else
                ltlMsg.Text = "Usuário já existente."
                ltlMsg.Visible = True
            End If
        Catch ex As Exception
            Log.WriteLog("Cadastro.btnCadastrar_Click", ex.Message.ToString)
        End Try
    End Sub

    Private Function IsEmailValid(ByVal email As String) As Boolean
        Dim padrao As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailMatch As Match = Regex.Match(email, padrao)
        If emailMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

End Class