﻿Public Class Busca
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Log As New Log
    Private Busca As New DALBusca
    Private intInicio As Integer
    Private inttamanhoPagina As Integer

#End Region

#Region "Protected"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri
            Me.nav.Visible = False
            If Not Me.Page.IsPostBack Then
                If Not Request.Params("result") Is Nothing Then
                    Dim args As String()
                    args = Request.Params("result").Split("|")
                    If UBound(args) = 1 Then
                        If args(0) = "Restaurantes" And args(1).ToString.Trim <> "" Then
                            Response.Redirect("~/Restaurantes_Det.aspx?parm=" & args(1).ToString, False)
                        ElseIf args(0) = "Receitas" And args(1).ToString.Trim <> "" Then
                            Response.Redirect("~/Receitas_Det.aspx?parm=" & args(1).ToString, False)
                        End If
                    End If
                End If

                Me.ddlQtde.Items.Clear()
                Me.ddlQtde.Items.Add(12)
                Me.ddlQtde.Items.Add(24)
                Me.ddlQtde.Items.Add(36)

            Else
                Paginacao.Controls.Clear()
                CriaPaginacao(ViewState("totalPaginas"))
            End If
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnBusca_Click(sender As Object, e As EventArgs) Handles btnBusca.Click
        Try
            ViewState("str") = Me.txtBusca.Text.Trim
            Me.SetBusca(ViewState("str"))
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.btnBusca_Click", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnPrev_Click(sender As Object, e As System.EventArgs) Handles btnPrev.Click
        Try
            Me.Voltar()
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.btnPrev_Click", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnNext_Click(sender As Object, e As System.EventArgs) Handles btnNext.Click
        Try
            Me.Avancar()
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.btnNext_Click", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub link_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = DirectCast(sender, LinkButton)
        PaginaAtual = Convert.ToInt32(link.Text) - 1
        Me.SetBusca(ViewState("str"))
    End Sub

    Protected Sub CriaPaginacao(pds As Integer)
        For i As Integer = 0 To pds - 1
            Dim link As New LinkButton()
            link.Text = (i + 1).ToString()
            link.ID = String.Concat("txt_", i.ToString())
            AddHandler link.Click, New EventHandler(AddressOf link_Click)
            Paginacao.Controls.Add(link)

            Dim space As New LiteralControl(" ")
            Paginacao.Controls.Add(space)
        Next
    End Sub

#End Region

#Region "Public"

    Public Sub SetBusca(str As String)
        Dim ds As DataSet
        Try
            If str.ToString.Length < 3 Then Return

            Me.nav.Visible = True
            Me.item_pag.Visible = True

            ds = Busca.Buscar(str)

            If ds.Tables(0).Rows.Count = 0 Then
                Me.nav.Visible = False
                Me.item_pag.Visible = False
                Me.rptResultado.Visible = False
                Me.ltlNaoLoc.Text = "Não foram localizados resultados para a sua pesquisa!"
                Me.ltlNaoLoc.Visible = True
            Else
                Me.ltlNaoLoc.Visible = False
                Me.rptResultado.Visible = True

                Dim pds As New PagedDataSource
                pds.DataSource = ds.Tables(0).DefaultView
                pds.AllowPaging = True
                pds.PageSize = Me.ddlQtde.SelectedValue

                pds.CurrentPageIndex = PaginaAtual

                lblCurrentPage.Text = "Página " + (PaginaAtual + 1).ToString + " de " + pds.PageCount.ToString

                If pds.PageCount > 1 Then
                    Paginacao.Visible = True
                End If

                Paginacao.Controls.Clear()
                ViewState("totalPaginas") = pds.PageCount
                CriaPaginacao(ViewState("totalPaginas"))

                rptResultado.DataSource = pds
                rptResultado.DataBind()

                Me.btnPrev.Visible = Not pds.IsFirstPage
                Me.btnNext.Visible = Not pds.IsLastPage

                End If

        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.SetBusca", ex.Message.ToString)
        Finally
            ds = Nothing
        End Try
    End Sub

#End Region

#Region "Private"

    Private Sub ddlQtde_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlQtde.SelectedIndexChanged
        Try
            ViewState("tamanhoPagina") = Me.ddlQtde.SelectedValue
            Me.SetBusca(ViewState("str"))
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.ddlQtde_SelectedIndexChanged", ex.Message.ToString)
        End Try
    End Sub

    Private Sub Voltar(Optional ByVal pagina As Integer = 1)
        Try
            PaginaAtual -= pagina
            Me.SetBusca(ViewState("str"))
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.Voltar", ex.Message.ToString)
        End Try
    End Sub

    Private Sub Avancar(Optional ByVal pagina As Integer = 1)
        Try
            PaginaAtual += pagina
            Me.SetBusca(ViewState("str"))
        Catch ex As Exception
            Log.WriteLog("Busca.aspx.vb.Avancar", ex.Message.ToString)
        End Try
    End Sub

    Private Property PaginaAtual() As Integer
        Get
            Dim o As Object = Me.ViewState("_PaginaAtual")
            If o Is Nothing Then
                Return 0
            Else
                Return CInt(o)
            End If
        End Get

        Set(value As Integer)
            Me.ViewState("_PaginaAtual") = value
        End Set
    End Property

#End Region

End Class