﻿Imports System.Data.SqlClient
Public Class DALBusca

    Private Log As New Log
    Private Dados As New DALDados

    Public Function Buscar(str As String) As DataSet
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_busca_receitas_restaurantes"

            cmd.Parameters.Clear()
            cmd.Parameters.Add("@criterio", SqlDbType.VarChar).Value = str

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("DALBusca.Buscar", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function TopView() As DataSet
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_carrega_topview"

            cmd.Parameters.Clear()

            Return Dados.RetornaDataSet(cmd)
        Catch ex As Exception
            Log.WriteLog("DALBusca.TopView", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

End Class
