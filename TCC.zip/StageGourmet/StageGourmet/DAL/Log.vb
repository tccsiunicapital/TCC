﻿Imports System.IO
Imports System.Web
Imports System.Text
Public Class Log
    Inherits System.Web.UI.Page

    Public Sub WriteLog(ByVal obj As String, ByVal msg As String)
        Dim sw As StreamWriter = File.AppendText(Me.Server.MapPath("Log") & "\logErro.txt")
        sw.WriteLine(Format(Date.Now, "yyyy-MM-dd HH:mm:ss.ff") & " | " & "Obj: " & obj & " | " & msg)
        sw.Close()
    End Sub

End Class
