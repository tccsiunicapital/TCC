﻿Imports StageGourmet.Log
Imports System.Data.SqlClient
Public Class DALDados

    Private Log As New Log
    Private Conn As New SqlConnection(ConfigurationManager.AppSettings.Get("MSSQL"))

    Public Function ExecutaQuery(ByVal query As SqlCommand) As Long
        Try
            query.Connection = Me.Conn
            If Conn.State <> ConnectionState.Closed Then Conn.Close()

            Conn.Open()
            ExecutaQuery = query.ExecuteNonQuery()

            Return ExecutaQuery
        Catch ex As Exception
            Log.WriteLog("DALDados.ExecutaQuery", ex.Message.ToString)
            Return -1
        Finally
            Conn.Close()
        End Try
    End Function

    Public Function ExecutaQuery_Retorno(ByVal query As SqlCommand) As Boolean
        Try
            query.Connection = Me.Conn
            If Conn.State <> ConnectionState.Closed Then Conn.Close()

            Conn.Open()
            query.ExecuteScalar()

            Return True
        Catch ex As Exception
            Log.WriteLog("DALDados.ExecutaQuery_Retorno", ex.Message.ToString)
            Return False
        Finally
            Conn.Close()
        End Try
    End Function

    Public Function RetornaDataSet(ByVal cmd As SqlCommand) As DataSet
        Try
            cmd.Connection = Me.Conn

            Dim da As New SqlDataAdapter(cmd)
            Dim ds As New DataSet

            If Conn.State <> ConnectionState.Closed Then Conn.Close()

            Conn.Open()
            da.Fill(ds)

            Return ds
        Catch ex As Exception
            Log.WriteLog("DALDados.RetornaDataSet", ex.Message.ToString)
            Return Nothing
        Finally
            Conn.Close()
        End Try
    End Function

    Public Function RetornaDataReader(cmd As SqlCommand) As SqlDataReader
        Try
            Dim dr As SqlDataReader
            cmd.Connection = Me.Conn

            If Conn.State <> ConnectionState.Closed Then Conn.Close()

            Conn.Open()
            dr = cmd.ExecuteReader()
            RetornaDataReader = dr
            Return RetornaDataReader
        Catch ex As Exception
            Log.WriteLog("DALDados.RetornaDataReader", ex.Message.ToString)
            Return Nothing
        Finally
            Conn.Close()
        End Try
    End Function
End Class
