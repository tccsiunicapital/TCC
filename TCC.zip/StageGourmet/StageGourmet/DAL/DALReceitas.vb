﻿Imports System.Data.SqlClient
Public Class DALReceitas

    Private Log As New Log
    Private Dados As New DALDados

    Public Function Cadastra(ByVal Nome As String, ByVal Desc As String, ByVal Ingredientes As String, ByVal Modo As String, ByVal Tipo As Integer, ByVal Prato As Integer, ByVal id_usuario As String) As Long
        Try
            Dim cmd As New SqlCommand

            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_insere_receita"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = Nome
            cmd.Parameters.Add("@descricao", SqlDbType.VarChar).Value = Desc
            cmd.Parameters.Add("@ingredientes", SqlDbType.Text).Value = Ingredientes
            cmd.Parameters.Add("@modo_preparo", SqlDbType.Text).Value = Modo
            cmd.Parameters.Add("@tipo_cozinha", SqlDbType.BigInt).Value = Tipo
            cmd.Parameters.Add("@tipo_prato", SqlDbType.BigInt).Value = Prato
            cmd.Parameters.Add("@id_usuario", SqlDbType.VarChar).Value = id_usuario

            Dim p As SqlParameter = cmd.Parameters.Add("@id_receita", SqlDbType.BigInt)

            p.Direction = ParameterDirection.Output
            Dados.ExecutaQuery_Retorno(cmd)

            Return CLng(p.Value)
        Catch ex As Exception
            Log.WriteLog("DALReceitas.Cadastra", ex.Message.ToString)
            Return -1
        End Try
    End Function

    Public Function TipoCozinha() As DataSet
        Try

            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_tipo_cozinha"
            cmd.Parameters.Clear()

            Return Dados.RetornaDataSet(cmd)
        Catch ex As Exception
            Log.WriteLog("DALReceitas.TipoCozinha", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function TipoPrato() As DataSet
        Try

            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_tipo_prato"
            cmd.Parameters.Clear()

            Return Dados.RetornaDataSet(cmd)
        Catch ex As Exception
            Log.WriteLog("DALReceitas.TipoPrato", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function Carrega(id As Long) As DataSet
        Try

            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_receita"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@id_receita", SqlDbType.BigInt).Value = id

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("DALReceitas.Carrega", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function Carrega() As DataSet
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_carrega_restaurantes_receitas"

            cmd.Parameters.Clear()
            cmd.Parameters.Add("@criterio", SqlDbType.VarChar).Value = "rec"

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("DALReceitas.Carrega", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function RegistraVisualizacao(id As Long) As Boolean
        Try
            RegistraVisualizacao = False

            Dim cmd As New SqlClient.SqlCommand

            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_insere_visualizacao"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@tipo", SqlDbType.VarChar).Value = "rec"
            cmd.Parameters.Add("@id_referencia", SqlDbType.BigInt).Value = id

            Return Dados.ExecutaQuery(cmd)

        Catch ex As Exception
            Log.WriteLog("DALReceitas.RegistraVisualizacao", ex.Message.ToString)
            RegistraVisualizacao = False
        End Try
    End Function

End Class
