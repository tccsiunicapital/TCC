﻿Imports System.Net.Mail

Public Class Email

#Region "Variaveis"

    Private Log As New Log

#End Region

#Region "Public"

    Public Function Envia(ByVal nomede As String, ByVal emailde As String, ByVal para As String, ByVal msg As String, ByVal link As String) As Boolean
        Try
            If para.Trim = "" Then Return False

            Dim oMail As New MailMessage
            Dim oSmtp As New SmtpClient

            oMail.From = New MailAddress(ConfigurationManager.AppSettings.Get("FROM"))

            emailde = emailde.Trim.ToLower
            nomede = nomede.Trim.ToUpper

            For Each t As String In para.Split(";")

                oMail.To.Add(t)

                oMail.Subject = "Link recomendado por " & nomede
                oMail.Body = "Olá , " & nomede & " (" & emailde & ")" & " recomendou esta página para você!" & vbCrLf & vbCrLf
                oMail.Body = oMail.Body & link
                oSmtp.Host = ConfigurationManager.AppSettings.Get("SMTP")
                oSmtp.Credentials = New System.Net.NetworkCredential(oMail.From.ToString, ConfigurationManager.AppSettings.Get("PWD"))
                oSmtp.EnableSsl = True

                oSmtp.Send(oMail)

                oMail.To.Clear()

            Next

            Return True
        Catch ex As Exception
            Log.WriteLog("Email.vb.Envia", ex.Message.ToString)
            Return False
        End Try
    End Function

#End Region

End Class
