﻿Public Class Usuario

    Private Log As New Log
    Private Dados As New DALDados

    Public Function LoginUsr(ByVal usuario As String, ByVal senha As String) As DataSet
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_login"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = usuario
            cmd.Parameters.Add("@senha", SqlDbType.VarChar).Value = senha

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("Usuario.vb.Login", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function Crypto(ByVal str As String) As String
        Try
            Dim md5Hasher As New System.Security.Cryptography.MD5CryptoServiceProvider()
            Dim hashedBytes As Byte()
            Dim encoder As New System.Text.UTF8Encoding()
            Dim s As String = ""

            hashedBytes = md5Hasher.ComputeHash(encoder.GetBytes(str))

            For Each y In hashedBytes
                s &= y
            Next y

            Crypto = s

            Return Crypto
        Catch ex As Exception
            Log.WriteLog("Usuario.Crypto", ex.Message.ToString)
            Return ""
        End Try
    End Function

    Public Function Cadastra(ByVal usuario As String, ByVal nome As String, ByVal senha As String) As Boolean
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_insere_login"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@id_usuario", SqlDbType.VarChar).Value = usuario
            cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = nome
            cmd.Parameters.Add("@senha", SqlDbType.VarChar).Value = senha

            Dim p As SqlClient.SqlParameter = cmd.Parameters.Add("@valida", SqlDbType.Bit)
            p.Direction = ParameterDirection.Output

            Dados.ExecutaQuery(cmd)

            Return p.Value
        Catch ex As Exception
            Log.WriteLog("Usuario.Cadastra", ex.Message.ToString)
            Return False
        End Try
    End Function

End Class
