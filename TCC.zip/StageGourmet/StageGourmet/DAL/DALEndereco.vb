﻿Imports System.Data.SqlClient
Public Class DALEndereco

    Private Dados As New DALDados
    Private Log As New Log

    Public Function RetornaUF() As DataSet
        Try
            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_uf"
            cmd.Parameters.Clear()

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("BLLEndereco.RetornaUF", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function RetornaCidade(ByVal uf As String) As DataSet
        Try
            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_cidade"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@uf", SqlDbType.VarChar).Value = uf

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("BLLEndereco.RetornaCidade", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

End Class
