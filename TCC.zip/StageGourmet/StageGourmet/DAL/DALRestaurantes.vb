﻿Imports System.Data.SqlClient
Public Class DALRestaurantes

    Private Log As New Log
    Private Dados As New DALDados

    Public Function Cadastra(Nome As String, Descricao As String, Logradouro As String, Numero As String, Complemento As String, Bairro As String, Municipio As String, UF As String, CEP As String, PrecoMin As Decimal, PrecoMax As Decimal, Site As String, Email As String, DDD As String, Fone As String, Tipo As Integer, ByVal id_usuario As String) As Long
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_insere_restaurante"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = Nome
            cmd.Parameters.Add("@descricao", SqlDbType.VarChar).Value = Descricao
            cmd.Parameters.Add("@logradouro", SqlDbType.VarChar).Value = Logradouro
            cmd.Parameters.Add("@numero", SqlDbType.VarChar).Value = Numero
            cmd.Parameters.Add("@complemento", SqlDbType.VarChar).Value = Complemento
            cmd.Parameters.Add("@bairro", SqlDbType.VarChar).Value = Bairro
            cmd.Parameters.Add("@municipio", SqlDbType.VarChar).Value = Municipio
            cmd.Parameters.Add("@uf", SqlDbType.VarChar).Value = UF
            cmd.Parameters.Add("@cep", SqlDbType.VarChar).Value = CEP
            cmd.Parameters.Add("@preco_minimo", SqlDbType.Money).Value = PrecoMin
            cmd.Parameters.Add("@preco_maximo", SqlDbType.Money).Value = PrecoMax
            cmd.Parameters.Add("@tipo_cozinha", SqlDbType.BigInt).Value = Tipo
            cmd.Parameters.Add("@site", SqlDbType.VarChar).Value = Site
            cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = Email
            cmd.Parameters.Add("@ddd", SqlDbType.VarChar).Value = DDD
            cmd.Parameters.Add("@telefone", SqlDbType.VarChar).Value = Fone
            cmd.Parameters.Add("@id_usuario", SqlDbType.VarChar).Value = id_usuario

            Dim p As SqlParameter = cmd.Parameters.Add("@id_restaurante", SqlDbType.BigInt)
            p.Direction = ParameterDirection.Output

            Dados.ExecutaQuery(cmd)

            Return CLng(p.Value)

        Catch ex As Exception
            Log.WriteLog("DALRestaurantes.Cadastra", ex.Message.ToString)
            Return -1
        End Try
    End Function

    Public Function TipoCozinha() As DataSet
        Try
            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_tipo_cozinha"
            cmd.Parameters.Clear()
            Return Dados.RetornaDataSet(cmd)
        Catch ex As Exception
            Log.WriteLog("DALRestaurantes.TipoCozinha", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function Carrega(id As Long) As DataSet
        Try
            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_retorna_restaurante"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@id_restaurante", SqlDbType.VarChar).Value = id

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("DALRestaurantes.Carrega", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function Carrega() As DataSet
        Try
            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_carrega_restaurantes_receitas"

            cmd.Parameters.Clear()
            cmd.Parameters.Add("@criterio", SqlDbType.VarChar).Value = "res"

            Return Dados.RetornaDataSet(cmd)

        Catch ex As Exception
            Log.WriteLog("DALRestaurantes.Carrega", ex.Message.ToString)
            Return Nothing
        End Try
    End Function

    Public Function RegistraVisualizacao(id As Long) As Boolean
        Try
            RegistraVisualizacao = False
            Dim cmd As New SqlCommand
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "sp_insere_visualizacao"
            cmd.Parameters.Clear()
            cmd.Parameters.Add("@tipo", SqlDbType.VarChar).Value = "res"
            cmd.Parameters.Add("@id_referencia", SqlDbType.BigInt).Value = id

            Return Dados.ExecutaQuery(cmd)

        Catch ex As Exception
            Log.WriteLog("DALReceitas.RegistraVisualizacao", ex.Message.ToString)
            RegistraVisualizacao = False
        End Try
    End Function

End Class
