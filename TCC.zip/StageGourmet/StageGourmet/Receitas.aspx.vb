﻿Public Class Receitas
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Log As New Log
    Private Receitas As New DALReceitas

#End Region

#Region "Protected"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri
        Try
            If Not Page.IsPostBack Then

                Me.ddlQtde.Items.Clear()
                Me.ddlQtde.Items.Add(12)
                Me.ddlQtde.Items.Add(24)
                Me.ddlQtde.Items.Add(36)

                Me.SetReceita()

            Else
                Paginacao.Controls.Clear()
                CriaPaginacao(ViewState("totalPaginas"))
            End If
        Catch ex As Exception
            Log.WriteLog("Receitas.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnPrev_Click(sender As Object, e As System.EventArgs) Handles btnPrev.Click
        Try
            Me.Voltar()
        Catch ex As Exception
            Log.WriteLog("Receitas.aspx.vb.btnPrev_Click", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnNext_Click(sender As Object, e As System.EventArgs) Handles btnNext.Click
        Try
            Me.Avancar()
        Catch ex As Exception
            Log.WriteLog("Receitas.aspx.vb.btnNext_Click", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub link_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = DirectCast(sender, LinkButton)
        PaginaAtual = Convert.ToInt32(link.Text) - 1
        Me.SetReceita()
    End Sub

    Protected Sub CriaPaginacao(pds As Integer)
        For i As Integer = 0 To pds - 1
            Dim link As New LinkButton()
            link.Text = (i + 1).ToString()
            link.ID = String.Concat("txt_", i.ToString())
            AddHandler link.Click, New EventHandler(AddressOf link_Click)
            Paginacao.Controls.Add(link)

            Dim space As New LiteralControl(" ")
            Paginacao.Controls.Add(space)
        Next
    End Sub

#End Region
    
#Region "Private"

    Private Sub SetReceita()
        Try
            Dim ds As DataSet = Receitas.Carrega()

            Dim pds As New PagedDataSource
            pds.DataSource = ds.Tables(0).DefaultView
            pds.AllowPaging = True
            pds.PageSize = Me.ddlQtde.SelectedValue

            pds.CurrentPageIndex = PaginaAtual

            lblCurrentPage.Text = "Página " + (PaginaAtual + 1).ToString + " de " + pds.PageCount.ToString

            If pds.PageCount > 1 Then
                Paginacao.Visible = True
            End If

            Paginacao.Controls.Clear()
            ViewState("totalPaginas") = pds.PageCount
            CriaPaginacao(ViewState("totalPaginas"))

            Me.btnPrev.Visible = Not pds.IsFirstPage
            Me.btnNext.Visible = Not pds.IsLastPage

            rptResultado.DataSource = pds
            rptResultado.DataBind()
        Catch ex As Exception
            Log.WriteLog("Receitas.aspx.vb.SetReceita", ex.Message.ToString)
        End Try
    End Sub

    Private Sub Voltar()
        Try
            PaginaAtual -= 1
            Me.SetReceita()
        Catch ex As Exception
            Log.WriteLog("Receitas.aspx.vb.Voltar", ex.Message.ToString)
        End Try
    End Sub

    Private Sub Avancar()
        Try
            PaginaAtual += 1
            Me.SetReceita()
        Catch ex As Exception
            Log.WriteLog("Receitas.aspx.vb.Avancar", ex.Message.ToString)
        End Try
    End Sub

    Private Property PaginaAtual() As Integer
        Get
            Dim o As Object = Me.ViewState("_PaginaAtual")
            If o Is Nothing Then
                Return 0
            Else
                Return CInt(o)
            End If
        End Get

        Set(value As Integer)
            Me.ViewState("_PaginaAtual") = value
        End Set
    End Property

#End Region

End Class