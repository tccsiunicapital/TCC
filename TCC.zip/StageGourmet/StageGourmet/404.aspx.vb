﻿Public Class _404
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri
    End Sub

End Class