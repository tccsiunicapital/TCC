﻿Public Class EnvioEmail
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Log As New Log
    Private Email As New Email

#End Region

#Region "Public"

    Public Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Me.IsPostBack Then
                Me.txtComentario.Text = Session("url_mail")
            End If
        Catch ex As Exception
            Log.WriteLog("EnvioEmail.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

#End Region

#Region "Protected"

    Protected Sub btnMail_Click(sender As Object, e As EventArgs) Handles btnMail.Click
        Try
            If Me.Envia() Then
                Me.ltlMsg.Text = "E-mail enviado!"
                Me.ltlMsg.Visible = True
            Else
                Me.ltlMsg.Text = "Não foi possível enviar o seu e-mail."
                Me.ltlMsg.Visible = True
            End If
        Catch ex As Exception
            Log.WriteLog("EnvioEmail.aspx.vb.btnMail_Click", ex.Message.ToString)
        End Try
    End Sub

#End Region

#Region "Private"

    Private Function Envia() As Boolean
        Try
            Return Email.Envia(txtNomeDe.Text, txtDe.Text, txtPara.Text, txtComentario.Text, Session("url_mail"))
        Catch ex As Exception
            Log.WriteLog("EnvioEmail.aspx.vb.Envia", ex.Message.ToString)
            Return False
        End Try
    End Function

#End Region

End Class