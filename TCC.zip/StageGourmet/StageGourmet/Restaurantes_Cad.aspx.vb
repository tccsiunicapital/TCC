﻿Public Class Restaurantes_Cad
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Restaurantes As New DALRestaurantes
    Private Endereco As New DALEndereco
    Private Log As New Log

#End Region

#Region "Protected"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri

            If Session("login") = "" Then
                Response.Redirect("/Login.aspx", False)
            End If

            If Not Me.Page.IsPostBack Then
                Me.lblStatus.Text = ""
                Me.PreencheRCozinha()
                Me.RetornaUF()
            End If
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub RetornaCidade(ByVal uf As String)
        Try
            Me.ddlMunicipio.Items.Clear()
            Me.ddlMunicipio.DataTextField = "LOC_NO"
            Me.ddlMunicipio.DataValueField = "LOC_NO"
            Me.ddlMunicipio.DataSource = Endereco.RetornaCidade(uf)
            Me.ddlMunicipio.DataBind()
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.RetornaCidade", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnEnviar_Click(sender As Object, e As EventArgs) Handles btnEnviar.Click
        Try
            Me.Cadastra()
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.btnEnviar_Click", ex.Message.ToString)
        End Try
    End Sub

#End Region

#Region "Private"

    Private Sub PreencheRCozinha()
        Try
            Me.rblTipoCozinha.Items.Clear()
            Me.rblTipoCozinha.DataTextField = "descricao"
            Me.rblTipoCozinha.DataValueField = "tipo_cozinha"
            Me.rblTipoCozinha.DataSource = Restaurantes.TipoCozinha()
            Me.rblTipoCozinha.DataBind()
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.PreencheComboCozinha", ex.Message.ToString)
        End Try
    End Sub

    Private Sub RetornaUF()
        Try
            Me.ddlUF.Items.Clear()
            Me.ddlUF.DataTextField = "ufe_sg"
            Me.ddlUF.DataValueField = "ufe_sg"
            Me.ddlUF.DataSource = Endereco.RetornaUF()
            Me.ddlUF.DataBind()
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.RetornaUF", ex.Message.ToString)
        End Try
    End Sub

    Private Sub ddlUF_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlUF.SelectedIndexChanged
        Try
            Me.RetornaCidade(Me.ddlUF.SelectedValue.ToString())
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.ddlUF_SelectedIndexChanged", ex.Message.ToString)
        End Try
    End Sub

    Private Sub Cadastra()
        Try

            If Session("login") = "" Then Exit Sub

            Dim Nome As String = Me.txtNome.Text.Trim
            Dim Descricao As String = Me.txtDescricao.Text.Trim
            Dim Logradrouro As String = Me.txtLogradouro.Text.Trim
            Dim Numero As String = Me.txtNumero.Text.Trim
            Dim Complemento As String = Me.txtComplemento.Text.Trim
            Dim Bairro As String = Me.txtBairro.Text.Trim
            Dim Municipio As String = Me.ddlMunicipio.SelectedItem.Value
            Dim UF As String = Me.ddlUF.SelectedItem.Value
            Dim Cep As String = Me.txtCEP.Text.Trim
            Dim PrecoDe As Decimal = CDbl(Me.txtPrecoDe.Text.Trim)
            Dim PrecoAte As Decimal = CDbl(Me.txtPrecoAte.Text.Trim)
            Dim Site As String = Me.txtSite.Text.Trim
            Dim Email As String = Me.txtEmail.Text.Trim
            Dim DDD As String = Me.txtDDD.Text.Trim
            Dim Fone As String = Me.txtFone.Text.Trim
            Dim Tipo As Integer = Me.rblTipoCozinha.SelectedItem.Value

            If Site.Trim <> "" Then
                If Not Site.StartsWith("http://") Then Site = "http://" & Site
            End If

            Dim i As Long = Restaurantes.Cadastra(Nome, Descricao, Logradrouro, Numero, Complemento, Bairro, Municipio, UF, Cep, PrecoDe, PrecoAte, Site, Email, DDD, Fone, Tipo, Session("login"))

            If i <= 0 Then
                Me.lblStatus.Text = "Erro ao cadastrar o restaurante."
            Else
                Me.SalvaImagem(i)
                Me.lblStatus.Text = "Restaurante Cadastrado!"
            End If
        Catch ex As Exception
            Log.WriteLog("Restaurantes_Cad.aspx.vb.Cadastra", ex.Message.ToString)
        End Try
    End Sub

    Private Sub SalvaImagem(id As Long)
        Try
            If FileUpload1.PostedFile IsNot Nothing Then
                Dim fileok As Boolean = False
                If FileUpload1.HasFile Then
                    Dim fileExtension As String = IO.Path.GetExtension(FileUpload1.FileName).ToLower
                    Dim allowedExtensions As [String]() = {".jpeg", ".jpg"}
                    For i As Integer = 0 To allowedExtensions.Length - 1
                        If fileExtension = allowedExtensions(i) Then
                            fileok = True
                        End If
                    Next
                End If
                If fileok Then
                    Dim nome_arquivo As String = id.ToString & ".jpg"
                    Dim path As String = Me.Server.MapPath("Imagens\Restaurantes\")
                    FileUpload1.SaveAs(path & nome_arquivo)
                End If
            End If
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.SalvaImagem", ex.Message.ToString)
        End Try
    End Sub
#End Region

End Class
