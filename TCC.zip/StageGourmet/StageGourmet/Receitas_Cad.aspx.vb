﻿Imports System.Drawing

Public Class Receitas_Cad
    Inherits System.Web.UI.Page

#Region "Variaveis"

    Private Receitas As New DALReceitas
    Private Log As New Log

#End Region

#Region "Protected"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri

            If Session("login") = "" Then
                Response.Redirect("/Login.aspx", False)
            End If

            If Not Me.Page.IsPostBack Then
                Me.lblStatus.Text = ""
                Me.PreencheRCozinha()
                Me.PreencheRPrato()
            End If
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.Page_Load", ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnEnviar_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEnviar.Click
        Try
            Me.Cadastra()
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.btnEnviar_Click", ex.Message.ToString)
        End Try
    End Sub

#End Region

#Region "Private"

    Private Sub Cadastra()
        Try

            If Session("login") = "" Then Exit Sub

            Dim nome As String = Me.txtNomeReceita.Text.Trim
            Dim desc As String = Me.txtDescReceita.Text.Trim
            Dim ingredientes As String = Me.txtIngredientes.Text.Trim
            Dim modo As String = Me.txtModoPreparo.Text.Trim
            Dim tipo_cozinha As Integer = Me.rblTipoCozinha.SelectedItem.Value
            Dim tipo_prato As Integer = Me.rblTipoPrato.SelectedItem.Value
            Dim id As Long = Receitas.Cadastra(nome, desc, ingredientes, modo, tipo_cozinha, tipo_prato, Session("login"))
            If id <= 0 Then
                Me.lblStatus.Text = "Erro ao enviar a receita."
            Else
                Me.lblStatus.Text = "Receita Enviada!"
                Me.SalvaImagem(id)
            End If
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.Cadastra", ex.Message.ToString)
        End Try
    End Sub

    Private Sub PreencheRCozinha()
        Try
            Me.rblTipoCozinha.Items.Clear()
            Me.rblTipoCozinha.DataTextField = "descricao"
            Me.rblTipoCozinha.DataValueField = "tipo_cozinha"
            Me.rblTipoCozinha.DataSource = Receitas.TipoCozinha()
            Me.rblTipoCozinha.DataBind()
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.PreencheComboCozinha", ex.Message.ToString)
        End Try
    End Sub

    Private Sub PreencheRPrato()
        Try
            Me.rblTipoPrato.Items.Clear()
            Me.rblTipoPrato.DataTextField = "nome_prato"
            Me.rblTipoPrato.DataValueField = "id_tipo_prato"
            Me.rblTipoPrato.DataSource = Receitas.TipoPrato()
            Me.rblTipoPrato.DataBind()
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.PreencheRadioButtonPrato", ex.Message.ToString)
        End Try
    End Sub

    Private Sub SalvaImagem(id As Long)
        Try
            If FileUpload1.PostedFile IsNot Nothing Then
                Dim fileok As Boolean = False
                If FileUpload1.HasFile Then
                    Dim fileExtension As String = IO.Path.GetExtension(FileUpload1.FileName).ToLower
                    Dim allowedExtensions As [String]() = {".jpeg", ".jpg"}
                    For i As Integer = 0 To allowedExtensions.Length - 1
                        If fileExtension = allowedExtensions(i) Then
                            fileok = True
                        End If
                    Next
                End If
                If fileok Then
                    Dim nome_arquivo As String = id.ToString & ".jpg"
                    Dim path As String = Me.Server.MapPath("Imagens\Receitas\")
                    FileUpload1.SaveAs(path & nome_arquivo)
                End If
            End If
        Catch ex As Exception
            Log.WriteLog("Receitas_Cad.aspx.vb.SalvaImagem", ex.Message.ToString)
        End Try
    End Sub

#End Region

End Class