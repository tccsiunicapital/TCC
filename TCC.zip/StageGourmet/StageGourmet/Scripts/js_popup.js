function fechar() {
document.getElementById('popup').style.display = 'none';
}
function abrir() {
document.getElementById('popup').style.display = 'block';
setTimeout ("fechar()", 3000);
}
function NovaJanela(pagina, nome, w, h, scroll) {
    LeftPosition = (screen.width) ? (screen.width - w) / 2 : 0;
    TopPosition = (screen.height) ? (screen.height - h) / 2 : 0;
    settings = 'height=' + h + ',width=' + w + ',top=' + TopPosition + ',left=' + LeftPosition + ',scrollbars=' + scroll + ',resizable'
    win = window.open(pagina, nome, settings);
}