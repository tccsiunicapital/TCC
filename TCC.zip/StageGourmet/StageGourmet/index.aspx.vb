﻿Public Class index
    Inherits System.Web.UI.Page

    Private Log As New Log
    Private Busca As New DALBusca
    Private PageSize As Integer = CInt(ConfigurationManager.AppSettings.Get("PageSizeIndex"))

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session("current_page") = HttpContext.Current.Request.Url.AbsoluteUri
        SetIndex()
    End Sub

    Private Sub SetIndex()
        Try
            Dim ds As DataSet
            ds = Busca.TopView

            Dim pds As New PagedDataSource

            'Restaurantes
            pds.DataSource = ds.Tables(0).DefaultView
            pds.AllowPaging = True
            pds.PageSize = PageSize

            rptResultadoRes.DataSource = pds
            rptResultadoRes.DataBind()

            'Limpa o PagedDataSource
            pds.DataSource = Nothing

            'Receitas
            pds.DataSource = ds.Tables(1).DefaultView
            pds.AllowPaging = True
            pds.PageSize = PageSize

            rptResultadoRec.DataSource = pds
            rptResultadoRec.DataBind()

            'Limpa o PagedDataSource e o DataSet
            pds.DataSource = Nothing
            ds = Nothing

        Catch ex As Exception
            Log.WriteLog("index.aspx.vb.SetIndex", ex.Message.ToString)
        End Try
    End Sub

End Class