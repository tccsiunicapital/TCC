﻿Imports System.Web
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Collections.Generic

Public Class AutoComplete
    Implements System.Web.IHttpHandler

#Region "Variaveis"

    Private Log As New Log
    Private Busca As New DALBusca
    Private Dados As New DALDados

#End Region

    Public Sub ProcessRequest(context As HttpContext) Implements IHttpHandler.ProcessRequest
        Try
            Dim parm As String = context.Request.QueryString("q")

            If parm.Trim.Length < 3 Then Exit Sub

            Dim ds As DataSet
            Dim i As Integer = 0
            'Dim list As New List(Of String)()

            ds = Busca.Buscar(parm)

            While i < ds.Tables(0).Rows.Count
                'Dim list As New List(Of String)()
                context.Response.Write(ds.Tables(0).Rows(i)("nome").ToString & Environment.NewLine)
                i = i + 1
            End While

            ds = Nothing
        Catch ex As Exception
            Log.WriteLog("AutoComplete.ashx.ProcessRequest", ex.Message.ToString)
        End Try
    End Sub

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class